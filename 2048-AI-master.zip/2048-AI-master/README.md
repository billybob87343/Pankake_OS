# 2048-AI
A fork of [2048](http://gabrielecirulli.github.io/2048/)

Made just for fun. [Play it here!](http://aj-r.github.io/2048-AI/)

